# Clinica VidaPlena

Sistema de terminal em Java puro para a clinica multidisciplinar VidaPlena.

## Como compilar e executar

Pre-requisito: JDK 8+ instalado (`javac` e `java` no PATH).

```bash
cd src
javac *.java
java Main
```

## Estrutura

- `Paciente.java` - cadastro de pacientes
- `Profissional.java` - cadastro de profissionais
- `Consulta.java` - agendamento, atendimento, cancelamento, remarcacao
- `Pagamento.java` - calculo e registro de pagamentos
- `Clinica.java` - armazenamento (arrays fixos + contadores) e operacoes globais
- `Main.java` - menus interativos via Scanner

## Restricoes respeitadas

- Sem heranca, classes abstratas, interfaces ou sobrescrita
- Sem Collections (ArrayList/HashMap/etc.) - apenas arrays fixos + variavel contadora
- Sem excecoes (`try/catch`)
- Sem getters/setters - todos os atributos sao publicos
- Sem modificadores de acesso restritos - tudo publico
- Datas como String "DD/MM/AAAA", comparacao com `.equals()`
- Entrada via `Scanner`

## Conceitos aplicados

- Sobrecarga de construtores em **5 classes**: Paciente, Profissional, Consulta, Pagamento, Clinica
- Sobrecarga de metodos em **5 classes**: Paciente (`complementar`), Profissional (`atualizar`, `atendeNoDia`), Consulta (`registrarAtendimento`, `cancelar`), Pagamento (`calcular`), Clinica (`listarConsultas`, `listarProfissionais`)
- Estruturas de decisao (`if/else`) e repeticao (`while`)
- Arrays com tamanho fixo + variavel contadora (pacientes, profissionais, consultas, pagamentos, dias, procedimentos)
- Metodos com retorno (`buscarPaciente`, `valorParcela`, `calcular`, ...) e sem retorno (`exibir`, `listar*`, ...)
