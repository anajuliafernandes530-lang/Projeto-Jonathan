# Documentacao - Clinica VidaPlena

## 1. Diagrama simplificado de classes

```
+--------------------------------+        +-------------------------------------+
|           Paciente             |        |            Profissional             |
+--------------------------------+        +-------------------------------------+
| + nome: String                 |        | + nome: String                      |
| + cpf: String                  |        | + especialidade: String             |
| + idade: int                   |        | + registro: String                  |
| + telefone: String             |        | + valorConsulta: double             |
| + convenio: String             |        | + diasAtendimento: String[7]        |
| + ativo: boolean               |        | + qtdDias: int                      |
| + multaPendente: double        |        +-------------------------------------+
+--------------------------------+        | + Profissional()                    |
| + Paciente()                   |        | + Profissional(nome, esp)           |
| + Paciente(nome, cpf)          |        | + Profissional(nome, esp, reg, val) |
| + Paciente(nome,cpf,idade,tel) |        | + Profissional(nome,esp,reg,val,    |
| + Paciente(...,convenio)       |        |               dias[], qtd)          |
| + complementar(idade,tel)      |        | + atualizar(reg, val)               |
| + complementar(idade,tel,conv) |        | + atualizar(reg, val, dias[], qtd)  |
| + complementar(conv)           |        | + atendeNoDia(dia): boolean         |
| + desativar()                  |        | + atendeNoDia(dia, exigeValor)      |
| + exibir()                     |        | + exibir()                          |
+--------------------------------+        +-------------------------------------+

+----------------------------------+        +----------------------------------+
|             Consulta             |        |             Pagamento            |
+----------------------------------+        +----------------------------------+
| + cpfPaciente: String            |        | + cpfPaciente: String            |
| + nomeProfissional: String       |        | + nomeProfissional: String       |
| + especialidade: String          |        | + data: String                   |
| + data: String  (DD/MM/AAAA)     |        | + tipoPagamento: String          |
| + hora: String  (HH:MM)          |        | + valorBase: double              |
| + tipo: String                   |        | + desconto: double               |
| + status: String                 |        | + multa: double                  |
| + motivoCancelamento: String     |        | + valorFinal: double             |
| + observacoes: String            |        | + parcelas: int                  |
| + diagnostico: String            |        +----------------------------------+
| + procedimentos: String[10]      |        | + Pagamento()                    |
| + qtdProcedimentos: int          |        | + Pagamento(cpf,val,tipo)        |
| + valorCobrado: double           |        | + Pagamento(cpf,val,tipo,parc)   |
+----------------------------------+        | + Pagamento(cpf,prof,data,...)   |
| + Consulta()                     |        | + calcular(valorBase): double    |
| + Consulta(cpf,prof,data,hora)   |        | + calcular(val,tipoCons,convenio)|
| + Consulta(cpf,prof,data,hora,t) |        | + calcular(val,tipo,conv,multa)  |
| + Consulta(cpf,prof,esp,...,t)   |        | + validarParcelas(): boolean     |
| + registrarAtendimento(obs)      |        | + valorParcela(): double         |
| + registrarAtendimento(obs,diag) |        | + exibir()                       |
| + registrarAtendimento(...,proc) |        +----------------------------------+
| + adicionarProcedimento(p): bool |
| + cancelar()                     |
| + cancelar(motivo)               |
| + exibir()                       |
+----------------------------------+

+----------------------------------------+
|                Clinica                 |
+----------------------------------------+
| + pacientes: Paciente[100]             |
| + qtdPacientes: int                    |
| + profissionais: Profissional[50]      |
| + qtdProfissionais: int                |
| + consultas: Consulta[500]             |
| + qtdConsultas: int                    |
| + pagamentos: Pagamento[500]           |
| + qtdPagamentos: int                   |
+----------------------------------------+
| + Clinica()                            |
| + Clinica(capPac)                      |
| + Clinica(capPac, capProf)             |
| + Clinica(capPac, capProf, capCons,    |
|           capPag)                      |
| + buscarPaciente(cpf): Paciente        |
| + adicionarPaciente(p): boolean        |
| + listarPacientes()                    |
| + buscarProfissional(nome)             |
| + buscarProfissionalDisponivel(...)    |
| + adicionarProfissional(p): boolean    |
| + especialidadeValida(e): boolean      |
| + listarProfissionais()                |
| + listarProfissionais(esp)             |
| + horarioOcupado(prof,data,hora)       |
| + sugerirHorario(prof,data): String    |
| + adicionarConsulta(c): boolean        |
| + listarConsultas()                    |
| + listarConsultas(cpf)                 |
| + listarConsultas(prof, true)          |
| + listarConsultas(d1, d2, true)        |
| + adicionarPagamento(p): boolean       |
| + listarPagamentos()                   |
| + resumoFinanceiro()                   |
+----------------------------------------+
```

Relacoes (associacao por valor textual, sem heranca):
- `Consulta.cpfPaciente` referencia `Paciente.cpf`
- `Consulta.nomeProfissional` referencia `Profissional.nome`
- `Pagamento.cpfPaciente` referencia `Paciente.cpf`
- `Clinica` agrega arrays de Paciente, Profissional, Consulta e Pagamento

## 2. Jornadas de usuario (10)

### J1 - Cadastro rapido de paciente
Ana abre o sistema -> menu Pacientes -> opcao 1 -> informa nome e CPF -> sistema cria paciente ativo.

### J2 - Complemento de cadastro com convenio
Paciente retorna -> menu Pacientes -> opcao 5 -> Ana informa CPF -> idade, telefone e convenio -> sistema atualiza.

### J3 - Tentativa de cadastro duplicado
Estagiaria informa CPF ja existente -> sistema recusa com mensagem `CPF ja cadastrado`.

### J4 - Cadastro de profissional com especialidade invalida
Tenta cadastrar com `cardiologia` -> sistema valida e recusa, pois so aceita 4 especialidades.

### J5 - Atualizacao completa de profissional
Profissional volta com registro, valor e dias -> menu Profissionais -> opcao 4 -> dados atualizados.

### J6 - Agendamento por especialidade
Paciente nao sabe o profissional -> menu Consultas -> opcao 2 -> sistema busca disponivel e agenda.

### J7 - Conflito e sugestao de horario
Tenta agendar em horario ocupado -> sistema sugere proximo horario livre entre 08h e 18h -> confirma.

### J8 - Registro de atendimento completo com 3 procedimentos
Profissional opta por opcao 5 -> informa observacoes, diagnostico e 3 procedimentos -> consulta vira `realizada`.

### J9 - Cancelamento com multa
Paciente liga 1h antes -> menu Consultas -> opcao 6 -> sistema calcula diferenca, aplica multa de R$ 50,00, registra motivo.

### J10 - Remarcacao para outro dia
Paciente quer mudar data e hora -> menu Consultas -> opcao 7 -> sistema valida dia do profissional, marca consulta antiga como `remarcada` e cria nova.

### J11 (bonus) - Pagamento calculado com convenio + multa
Pedro tem convenio e multa pendente -> menu Pagamentos -> opcao 4 -> sistema aplica 20% (retorno) + 40% (convenio) + soma multa -> paga em 3x no cartao.

### J12 (bonus) - Desativacao de paciente bloqueia agendamento
Lucas desativado -> tentativa de agendamento -> sistema bloqueia com `Paciente INATIVO`.

### J13 (bonus) - Resumo financeiro do dia
Gerente pede relatorio -> menu Relatorios -> opcao 4 -> sistema soma faturamento, multas, conta atendimentos e cancelamentos.
